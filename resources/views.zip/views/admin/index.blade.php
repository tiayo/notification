
<!DOCTYPE html Public "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>祥景CMS</title>
<link href="/Houtai/style.css" rel="stylesheet"/>
<script src="/Houtai/jquery.js"></script>
<link href="/Houtai/style.css" rel="stylesheet" type="text/css" />
</head>
  
<frameset rows="88,*" cols="*" frameborder="NO" border="0" framespacing="0">
  <frame src="/admin/top" name="topFrame" scrolling="NO" noresize="noresize" id="topFrame" title="topFrame" />
  <frameset cols="187,*" frameborder="NO" border="0" framespacing="0">
    <frame src="/admin/left" name="leftFrame" scrolling="NO" noresize="noresize" id="leftFrame" title="leftFrame" />
    <frame src="/admin/main" name="rightFrame" id="rightFrame" title="rightFrame" />
  </frameset>
</frameset>
<noframes><body>
</body></noframes>
</html>