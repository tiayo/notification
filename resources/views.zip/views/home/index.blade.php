<!DOCTYPE html Public "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>随享采集系统</title>
</head>
  
<frameset rows="88,*" cols="*" frameborder="NO" border="0" framespacing="0">
  <frame src="/top" name="topFrame" scrolling="NO" noresize="noresize" id="topFrame" title="topFrame" />
  <frameset cols="187,*" frameborder="NO" border="0" framespacing="0">
    <frame src="/left" name="leftFrame" scrolling="NO" noresize="noresize" id="leftFrame" title="leftFrame" />
    <frame src="/main" name="rightFrame" id="rightFrame" title="rightFrame" />
  </frameset>
</frameset>
<noframes><body>
</body></noframes>
</html>
