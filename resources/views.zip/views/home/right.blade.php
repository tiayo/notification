<!DOCTYPE html Public "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/jquery.js"></script>

<script type="text/javascript">
$(document).ready(function(){
  $(".click").click(function(){
  $(".tip").fadeIn(200);
  });
  
  $(".tiptop a").click(function(){
  $(".tip").fadeOut(200);
});

  $(".sure").click(function(){
  $(".tip").fadeOut(100);
});

  $(".cancel").click(function(){
  $(".tip").fadeOut(100);
});

});
</script>
<script>
$(document).ready(function(){
	//全选
	$('#quanxuan').click(function(){
	  panduan = $("#quanxuan").prop("checked");
	  if(panduan == true){
		  $("input").prop("checked", 'checked');
	  }else{
		  $("input").prop("checked", false);
	}
  })
})
</script>
</head>


<body>

	<div class="place">
    <span>位置：</span>
    <ul class="placeul">
    <li><a href="#">首页</a></li>
    <li><a href="#">我的分享</a></li>
    </ul>
    </div>
    
    <div class="rightinfo">
    
    <div class="tools">
    
    	<ul class="toolbar">
        <li><a href="/Admin/list/xinxi_view?id=1"><span><img src="/images/t01.png" /></span>添加</a></li>
        <li><span><img src="/images/t02.png" /></span>修改</li>
        <li class="click"><span><img src="/images/t03.png" /></span>删除</li>
        <form class="form" action="/Admin/List/admin_serch_list" method="get">
        <select name="lanmu" class="lanmu">
            <option>{$lanmu|default="选择栏目..."}</option>
            <foreach name='all_list' item='all_list'>
              <option>{$all_list[mingcheng]}</option>
            </foreach>
          </select>
          <input type="hidden" name='id' value="{$list_id}" />
          <input type="text" class="text" name="text"  value="{$text}" placeholder="输入关键词" />
          <input type="submit" class="submit"  />
        </form>
        </ul>
        
        
        <ul class="toolbar1">
            <li class="paginItem"><a href="?tid={$page_pre}">上一页</a></li>
		    <foreach name='fenye_li'  item='fenye'>
		         	{$fenye}
		    </foreach>
   			<if condition="$yeshu EGT 5">  
                <li class="paginItem">
                    <select class="lanmu" onchange="window.location=this.value;">
                        <option value="">更多</option>
                        <foreach name='fenye_option'  item='fenye_2'>
                                {$fenye_2}
                        </foreach>
                    </select>
                </li>
            </if>
	        <li class="paginItem"><a href="?tid={$page_next}">下一页</a></li>
		</ul>
    
    </div>
    

   
<form method="post" action="/admin/index/article_delete_duo">    
    
    <table class="tablelist">
    	<thead>
    	<tr>
        <th><input name="checkbox101" type="checkbox" value="101"  id="quanxuan"/></th>
        <th>编号<i class="sort"><img src="/images/px.gif" /></i></th>
        <th>标题</th>
        <th>用户</th>
        <th>阅读</th>
        <th>发布时间</th>
        <th>类型</th>
        <th>状态</th>
        <th>操作</th>
        </tr>
        </thead>
        <tbody>
<foreach name='right_article'  item='row'>
		<tr>
        <td><input name="xuanze{++$i}" value="{$row[aid]}" type="checkbox" id="xuanze"/></td>
        <td>{$row[aid]}</td>
        <td>{$row[title]}</td>
        <td>{$row[writer]}</td>
        <td>{$row[click]}</td>
        <td>{$row[fabutime] | date = 'Y-m-d H:i:s',###}</td>
		<td>
			{$list_mingcheng[$key][mingcheng]}
		</td>
        <td>
            <switch name="row.shuxing" >
                <case value="1" break="1">普通</case>
                <case value="3" break="1">置顶</case>
                <default />未获取
            </switch>
        </td>
        <td>
   		<if condition="$lanmu_caozuo eq 1">  
            <a href="/Admin/List/beiwang?aid={$row[aid]}" class="tablelink">
                <switch name="row.shuxing" >
                    <case value="1" break="1">设为置顶</case>
                    <case value="3" break="1">取消取消</case>
                    <default />未获取
                </switch>
            </a>
   		</if>  
         <a href="/home/article?aid={$row[aid]}" class="tablelink" target="_blank">查看</a>     <a href="/admin/index/article_xiugai?aid={$row[aid]}" class="tablelink">编辑</a>     <a href="/admin/index/article_delete?delete={$row[aid]}" class="tablelink"> 删除</a></td>
        </tr> 
</foreach>

        </tbody>
    </table>
    
   
    <div class="pagin">
    	<div class="message">共<i class="blue">{$num_article}</i>条记录，当前显示第<i class="blue">{$page}</i>页</div>
        <ul class="paginList">    
	        <li class="paginItem"><a href="?tid={$page_pre}">上一页</a></li>
		    <foreach name='fenye_li'  item='fenye'>
		         	{$fenye}
		    </foreach>
   			<if condition="$yeshu EGT 5">  
                <li class="paginItem"><a>
                    <select class="lanmu" onchange="window.location=this.value;">
                      <option value="">更多</option>
                        <foreach name='fenye_option'  item='fenye_2'>
                                {$fenye_2}
                        </foreach>
                    </select>
                </a></li>
   			</if>  
	        <li class="paginItem"><a href="?tid={$page_next}">下一页</a></li>
        </ul>
    </div>
    
    
    <div class="tip">
    	<div class="tiptop"><span>提示信息</span><a></a></div>
        
      <div class="tipinfo">
        <span><img src="/images/ticon.png" /></span>
        <div class="tipright">
        <p>是否确认对信息的修改 ？</p>
        <cite>如果是请点击确定按钮 ，否则请点取消。</cite>
        </div>
      </div>
        
        <div class="tipbtn">
        <input name="submit" type="submit"  class="sure" value="确定" />&nbsp;
        <input name="" type="button"  class="cancel" value="取消" />
        </div>
    
    </div>
</form>    
 
    
    </div>
    
<script type="text/javascript">
	$('.tablelist tbody tr:odd').addClass('odd');
	</script>

</body>

</html>
